package us.mattgreen;

/**
 * Created by mgreen14 on 12/27/17.
 */
public interface Talkable {
    String talk();
    String getName();
}
